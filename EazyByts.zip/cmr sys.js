// scripts.js

function getContacts() {
    return JSON.parse(localStorage.getItem('contacts')) || [];
}

function saveContacts(contacts) {
    localStorage.setItem('contacts', JSON.stringify(contacts));
}

function addContact() {
    const name = document.getElementById('contact-name').value;
    const email = document.getElementById('contact-email').value;
    const phone = document.getElementById('contact-phone').value;

    if (!name || !email || !phone) {
        alert("All fields are required!");
        return;
    }

    const contacts = getContacts();
    contacts.push({
        name,
        email,
        phone
    });
    saveContacts(contacts);
    displayContacts();
}

function displayContacts() {
    const contacts = getContacts();
    const contactsList = document.getElementById('contacts-list');
    contactsList.innerHTML = '';
    contacts.forEach((contact, index) => {
        const contactDiv = document.createElement('div');
        contactDiv.classList.add('contact-item');
        contactDiv.innerHTML = `
            <p>Name: ${contact.name}</p>
            <p>Email: ${contact.email}</p>
            <p>Phone: ${contact.phone}</p>
            <button onclick="deleteContact(${index})">Delete</button>
        `;
        contactsList.appendChild(contactDiv);
    });
}

function deleteContact(index) {
    const contacts = getContacts();
    contacts.splice(index, 1);
    saveContacts(contacts);
    displayContacts();
}

document.addEventListener('DOMContentLoaded', displayContacts);

// Repeat similar functions for Sales, Tasks, and Support Tickets